from django.apps import AppConfig


class AccessTokenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'access_token'
