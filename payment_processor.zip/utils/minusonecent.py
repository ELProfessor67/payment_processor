

def minusonecent(dollar) -> int:
    dollartocent:int = int(dollar) * 100
    dollartocent -= int(dollar)

    return dollartocent/100